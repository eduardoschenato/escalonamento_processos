<?php

final class FCFS extends Algoritmo {

    public function __construct() {
        parent::__construct();
    }

    public function executar(array $processos) {
        //TODO Alan
    }

}
